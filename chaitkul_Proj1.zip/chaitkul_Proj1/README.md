ENPM 662 - Project 1

Name: Chaitanya Kulkarni	
UID: 119183502
Directory ID: chaitkul	

Instructions to run the code:

1. Extract the "batmobile.zip" folder and place it in the src folder of your workspace.

2. Build and source the package.

3. For teleop, change the robot spawn location to x=1, y=0, and z=0.5 and yaw angle=80.0. Build and source the package.

4. Use the following command:
	Terminal 1:
		ros2 launch batmobile competition.launch.py
	Terminal 2:
		cd src/batmobile/scripts
		./teleop.py
	Use w,a,s,d to control the robot
	
5. For closed loop controller, change the robot spawn location to x=0, y=0, z=0.5 and r=p=y=0.0

6. Use the following command:
	Terminal 1:
		ros2 launch batmobile gazebo.launch.py
	Terminal 2:
		cd src/batmobile/scripts
		./pub_sub.py
	The robot will move from (0,0) to (10,10) and the error and control vs time plot will be displayed.
	The terminal will show published data and the subscribed data.

7. The zip folder contains "batmobile.zip" which is the ROS package and the "batmobile_assembly.zip" which contains SolidWorks parts and assmebly.

Teleop Video Link: https://drive.google.com/file/d/1ueMxM5ZiQgmddjBytjmZbsHmCgBnTXUB/view?usp=drive_link

Closed Loop Controller Link: https://drive.google.com/file/d/1C5eROC5pQ9rUPgUddYyU0OyPzBizt9Ti/view?usp=drive_link

7. The video links have also been mentioned in the project report.
